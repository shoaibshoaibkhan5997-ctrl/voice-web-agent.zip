# Voice Web Agent (APK)

Hindi me bolkar apni website ka code badlo. Gemini API (free) + GitHub.

## APK kaise banaye (computer ki zarurat nahi)
1. github.com par naya repo banao (jaise `voice-web-agent`).
2. Is zip ki saari files us repo me upload karo (`.github` folder samet).
3. Repo me **Actions** tab -> "Build APK" -> **Run workflow**.
4. 5-10 minute baad run ke andar **Artifacts** me `app-debug-apk` download karo.
5. Zip kholkar `app-debug.apk` phone me install karo (Unknown sources allow karna padega).

## App me settings
- **Gemini key:** https://aistudio.google.com -> Get API key (free).
- **GitHub token:** GitHub -> Settings -> Developer settings -> Fine-grained tokens.
  Sirf apni website wale repo ko chuno, permission: Contents = Read and write.
- **Repo:** `owner/naam`, **Branch:** `main`.

## Kaise chalta hai
Files lao -> file chuno -> mic dabao aur bolo -> Preview dekho -> "GitHub par save karo".
Galat lage to "pichla version wapas lao".
